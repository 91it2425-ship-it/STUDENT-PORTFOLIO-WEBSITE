import React, { useState } from "react";

const App = () => {
  const [student, setStudent] = useState({
    name: "",
    course: "",
    year: "",
    skills: "",
    bio: "",
  });

  const [students, setStudents] = useState([]); 
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value });
  };

  const handleAddStudent = (e) => {
    e.preventDefault();
    if (!student.name || !student.course) {
      setError("Please fill at least Name and Course!");
      return;
    }
    setStudents([...students, student]);
    setStudent({ name: "", course: "", year: "", skills: "", bio: "" });
    setError("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-indigo-500 to-blue-400 flex flex-col items-center p-6">
      <h1 className="text-4xl font-bold text-white mb-6">
        🎓 Student Portfolio Collection
      </h1>

      {/* Form Section */}
      <form
        onSubmit={handleAddStudent}
        className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-md mb-8"
      >
        {error && <p className="text-red-500 mb-3">{error}</p>}

        <label className="block mb-3">
          <span className="text-gray-700 font-semibold">Full Name</span>
          <input
            type="text"
            name="name"
            value={student.name}
            onChange={handleChange}
            required
            className="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:ring focus:ring-indigo-300"
          />
        </label>

        <label className="block mb-3">
          <span className="text-gray-700 font-semibold">Course</span>
          <input
            type="text"
            name="course"
            value={student.course}
            onChange={handleChange}
            required
            className="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:ring focus:ring-indigo-300"
          />
        </label>

        <label className="block mb-3">
          <span className="text-gray-700 font-semibold">Year</span>
          <input
            type="text"
            name="year"
            value={student.year}
            onChange={handleChange}
            placeholder="e.g. 3rd Year"
            className="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:ring focus:ring-indigo-300"
          />
        </label>

        <label className="block mb-3">
          <span className="text-gray-700 font-semibold">Skills</span>
          <input
            type="text"
            name="skills"
            value={student.skills}
            onChange={handleChange}
            placeholder="e.g. React, Python, C++"
            className="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:ring focus:ring-indigo-300"
          />
        </label>

        <label className="block mb-4">
          <span className="text-gray-700 font-semibold">Short Bio</span>
          <textarea
            name="bio"
            value={student.bio}
            onChange={handleChange}
            rows="3"
            className="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:ring focus:ring-indigo-300"
          ></textarea>
        </label>

        <button
          type="submit"
          className="bg-indigo-600 text-white font-semibold w-full py-2 rounded-lg hover:bg-indigo-700 transition"
        >
          ➕ Add Student
        </button>
      </form>

      {/* Portfolio Display Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-6xl">
        {students.map((s, index) => (
          <div
            key={index}
            className="bg-white shadow-lg rounded-2xl p-6 text-gray-700 hover:shadow-2xl transition"
          >
            <h2 className="text-2xl font-bold mb-2 text-indigo-600">{s.name}</h2>
            <p className="text-sm mb-1">{s.course}</p>
            <p className="text-sm mb-2">{s.year}</p>
            <p className="font-semibold mt-3">Skills:</p>
            <p className="text-sm">{s.skills}</p>
            <p className="font-semibold mt-3">About:</p>
            <p className="text-sm">{s.bio}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
